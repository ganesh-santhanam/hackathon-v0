# AMD Hackathon LLM-as-Judge Evaluation

## Executive Summary

- Examples evaluated: 10
- Judge model: Qwen/Qwen3-14B
- Judge provider: openai-compatible
- Hallucination score is lower-is-better; all other metrics are higher-is-better.

## Candidate Models

| Candidate | Model | Examples |
| --- | --- | --- |
| base | Qwen/Qwen3-4B-Instruct-2507 | 10 |
| lora | Qwen/Qwen3-4B-Instruct-2507+data/amd/lora/qwen4b_adapter | 10 |

## Mean Scores

| Metric | Base Mean | LoRA Mean | LoRA Improvement % |
| --- | --- | --- | --- |
| hallucination_score | 1.0 | 1.0 | 0.0 |
| rca_quality | 3.7 | 4.6 | 24.32 |
| actionability | 4.4 | 4.4 | 0.0 |
| severity_reasoning | 3.8 | 4.6 | 21.05 |

## Key Findings

- Use the mean-score table directly in PowerPoint to compare base and LoRA behavior.
- Use hallucination score to show evidence grounding; lower LoRA values indicate better grounding.
- Use RCA quality, actionability, and severity reasoning to show domain-specific investigation gains.

## Conclusions

- The pipeline preserves prompts, responses, judge scores, and model metadata for auditability.
- Results are generated from local JSONL artifacts and can run on a laptop or AMD Cloud instance.
